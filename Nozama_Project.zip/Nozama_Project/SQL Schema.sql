DROP TABLE Book;

CREATE TABLE Book (
bid VARCHAR(20) NOT NULL,
title VARCHAR(60) NOT NULL,
price INTEGER NOT NULL,
category VARCHAR(20) check (category in ('Science', 'Fiction', 'Engineering')) NOT NULL,
PRIMARY KEY(bid)
);

INSERT INTO Book (bid, title, price, category) VALUES ('b001', 'Little Prince', 20, 'Fiction');
INSERT INTO Book (bid, title, price, category) VALUES ('b002','Physics 101', 201, 'Science');
INSERT INTO Book (bid, title, price, category) VALUES ('b003','Mechanics' ,120,'Engineering');
INSERT INTO Book (bid, title, price, category) VALUES ('b004','Mechatronics' ,130,'Engineering');
INSERT INTO Book (bid, title, price, category) VALUES ('b005','Chemistry 101' ,140,'Science');
INSERT INTO Book (bid, title, price, category) VALUES ('b006','Biology 101' ,150,'Science');
INSERT INTO Book (bid, title, price, category) VALUES ('b007','Diary of a wimpy kid' ,35,'Fiction');
INSERT INTO Book (bid, title, price, category) VALUES ('b008','Human Anatomy' ,120,'Science');
INSERT INTO Book (bid, title, price, category) VALUES ('b009','Kinesiolgy 111' ,135, 'Science');
INSERT INTO Book (bid, title, price, category) VALUES ('b010','Money Management' ,150,'Science');


DROP TABLE Address;

CREATE TABLE Address (
id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
street VARCHAR(100) NOT NULL,
province VARCHAR(20) NOT NULL,
country VARCHAR(20) NOT NULL,
zip VARCHAR(20) NOT NULL,
phone VARCHAR(20),
city VARCHAR(20),
PRIMARY KEY(id)
);

INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('123 Yonge St', 'ON', 'Canada', 'K1E 6T5' ,'647-123-4567', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('445 Avenue Rd.', 'ON', 'Canada', 'M1C 6K5' ,'416-123-8569', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('789 Keele St.', 'ON', 'Canada', 'K3C 9T5' ,'416-123-9568', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('19 Silvercrest St.', 'ON', 'Canada', 'K3C 9T5' ,'416-321-8659', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('1443 Chinguacousy Rd.', 'ON', 'Canada', 'K4C 7T5' ,'416-489-1597', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('27 Starhill Cres.', 'ON', 'Canada', 'K9C 4T3' ,'905-951-2365', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('143 Firefly lane', 'ON', 'Canada', 'Q3D 9F5' ,'905-426-6587', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('444 Queen St.', 'ON', 'Canada', 'A7C 8T8' ,'416-441-7771', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('975 Timber Dr.', 'ON', 'Canada', 'L5C 9W5' ,'647-892-5849', 'Toronto');
INSERT INTO Address (street, province, country, zip, phone, city) VALUES ('14 Oliveway St.', 'ON', 'Canada', 'G7X 9T7' ,'647-593-2687', 'Toronto');

DROP TABLE PO;

CREATE TABLE PO (
id INTEGER UNSIGNED GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
uid INTEGER NOT NULL,
status VARCHAR(20) check (status in ('ORDERED','PROCESSED','DENIED')) NOT NULL,
address INT UNSIGNED NOT NULL,
PRIMARY KEY(id),
FOREIGN KEY (uid) REFERENCES User (id),
FOREIGN KEY (address) REFERENCES Address (id)
);

INSERT INTO PO (uid, status, address) VALUES (1, 'PROCESSED', '1');
INSERT INTO PO (uid, status, address) VALUES (2, 'DENIED', '2');
INSERT INTO PO (uid, status, address) VALUES (3, 'ORDERED', '3');
INSERT INTO PO (uid, status, address) VALUES (4, 'PROCESSED', '4');
INSERT INTO PO (uid, status, address) VALUES (5, 'ORDERED', '5');
INSERT INTO PO (uid, status, address) VALUES (6, 'ORDERED', '6');
INSERT INTO PO (uid, status, address) VALUES (7, 'ORDERED', '7');
INSERT INTO PO (uid, status, address) VALUES (8, 'ORDERED', '8');
INSERT INTO PO (uid, status, address) VALUES (9, 'PROCESSED', '9');
INSERT INTO PO (uid, status, address) VALUES (10, 'PROCESSED', '10');

DROP TABLE POItem;

CREATE TABLE POItem (
id INT UNSIGNED NOT NULL,
bid VARCHAR(20) NOT NULL,
price INT UNSIGNED NOT NULL,
FOREIGN KEY(id) REFERENCES PO(id) ON DELETE CASCADE,
FOREIGN KEY(bid) REFERENCES Book(bid) ON DELETE CASCADE
);

INSERT INTO POItem (id, bid, price) VALUES (1, 'b001', '20');
INSERT INTO POItem (id, bid, price) VALUES (2, 'b002', '201');
INSERT INTO POItem (id, bid, price) VALUES (3, 'b003', '120');
INSERT INTO POItem (id, bid, price) VALUES (4, 'b004', '130');
INSERT INTO POItem (id, bid, price) VALUES (5, 'b005', '140');
INSERT INTO POItem (id, bid, price) VALUES (6, 'b006', '150');
INSERT INTO POItem (id, bid, price) VALUES (7, 'b007', '35');
INSERT INTO POItem (id, bid, price) VALUES (8, 'b008', '120');
INSERT INTO POItem (id, bid, price) VALUES (9, 'b009', '135');
INSERT INTO POItem (id, bid, price) VALUES (10, 'b010', '150');

CREATE TABLE VisitEvent (
day varchar(8) NOT NULL,
bid varchar(20) not null REFERENCES Book.bid,
eventtype VARCHAR(20) check (eventtype in ('VIEW','CART','PURCHASE')) NOT NULL,
FOREIGN KEY(bid) REFERENCES Book(bid)
);

INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('12202015', 'b001', 'VIEW');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('12242015', 'b001', 'CART');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('12252015', 'b002', 'PURCHASE');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('12262015', 'b003', 'VIEW');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('12262015', 'b004', 'PURCHASE');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('01032016', 'b005', 'CART');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('01032016', 'b006', 'CART');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('01042016', 'b007', 'PURCHASE');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('01052016', 'b008', 'VIEW');
INSERT INTO VisitEvent (day, bid, eventtype) VALUES ('01062016', 'b009', 'PURCHASE');

DROP TABLE User;

CREATE TABLE User (
id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
email VARCHAR(20) NOT NULL,
password VARCHAR(50) NOT NULL,
fname VARCHAR(20) NOT NULL,
lname VARCHAR(20) NOT NULL,
daddressid INTEGER NOT NULL,
role VARCHAR(20) check (role in ('VISITOR', 'CUSTOMER', 'ADMIN', 'PARTNER')) NOT NULL DEFAULT 'VISITOR',
PRIMARY KEY (id),
FOREIGN KEY (daddressid) REFERENCES Address(id)
);

INSERT INTO User (email, password, fname, lname, daddressid, role) VALUES ('johnwhite@proj.com', 'passpass', 'John', 'White', '1', 'VISITOR');
INSERT INTO User (email, password, fname, lname, daddressid, role) VALUES ('peterblack@proj.com', 'wordword', 'Peter', 'Black', '2', 'ADMIN');
INSERT INTO User (email, password, fname, lname, daddressid, role) VALUES ('andygreen@proj.com', 'password', 'Andy', 'Green', '3', 'CUSTOMER);

CREATE TABLE Rating (
rating varchar(10) NOT NULL,
name varchar(20) NOT NULL,
bid varchar(20) NOT NULL REFERENCES
message varchar(100) NOT NULL,
FOREIGN KEY(bid) REFERENCES Book(bid)
);

CREATE TABLE TOP_BOOKS (
bid varchar(20) NOT NULL,
total int NOT NULL
FOREIGN KEY(bid) REFERENCES Book(bid)
);
