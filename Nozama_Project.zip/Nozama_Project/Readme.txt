Steps to run the application:
1. Run locally by running the Start.java file on TomCat. (context.xml file is updated with Cloud DB)
2. Search books by category or title.
3. Sign in using one of the three users:
	user: johnwhite@proj.com 	password: passpass 	role: VISITOR
	user: peterblack@proj.com	password: wordword	role: ADMIN
	user: andygreen@proj.com 	password: password	role: CUSTOMER
4. Add to Cart which shows price but not book (not sure why). Book can be seen in the console.
5. Confirm Order which takes you to Log in page if not registered. If registered, go to payment page.
6. Enter payment information.
7. Process Payment.
8. Redirected to Payment confirmed or denied page.
9. From this page, you can either go to Home page or Logout.


SIDE NOTES:
-Some of the aspects of the code does not work on the JSPX pages but does show up in the console if proof
 is needed.
-We have tested the code multiple times and it works on our end, in some circumstances where it does not
 work on your end, feel free to contact at javaid21@my.yorku.ca and we can demo the code.
-Everything else is explained in the Design Document.
